
#A skeleton for implementing the kMeans Clustering algorithm. 
#Requires the name of the file, the number of clusters, and maximum number of iteration

## Author: Salem <Salem@SALEM-OFFICE>
## Created: 2012-10-29

import numpy
import random
import time

filename = "twoCircles.txt"
k=2
maxIterations = 20
epsilonThreshold =0.00001
    
    data = numpy.loadtxt(filename)
    means = numpy.zeros((k,data.shape[1])) #This is for holding the means..
    membership = numpy.zeros(len(data)) #This is for the clustering assignment
    delta = 1 #to pass the initial test..
    iterations = 0
    
    #Choose k random points as the initial means..

    while iterations < maxIterations  and delta > epsilonThreshold : #Keep iterating as long 
        
        #Calculate membership
        #For every point, assign it to the closest cluster..

        #Find New Means
        
        #calculate Delta, difference between the old means and the new means..

#Here..  
#membership should have the final clustering assignments, which cluster every point is assigned to..
